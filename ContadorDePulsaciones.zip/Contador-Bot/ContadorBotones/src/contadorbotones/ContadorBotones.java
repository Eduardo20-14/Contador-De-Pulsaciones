//Eduardo Martinez Becerra
package contadorbotones;

public class ContadorBotones {

   
    public static void main(String[] args) {
        GUI v = new GUI ();
        v.setVisible(true);
        
    }
    
}