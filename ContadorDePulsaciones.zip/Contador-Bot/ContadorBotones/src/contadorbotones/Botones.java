//Eduardo Martinez Becerra

package contadorbotones;

import Contador.Contador;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Botones extends JButton {
    
    public JButton boton1;
    public JButton boton2;
    public JButton boton3;
    
    public Botones(){
        boton1=new JButton();
        boton2=new JButton();
        boton3=new JButton();
          disenobotones();
    }
  
    

    public void disenobotones(){
        
        boton1.setText("Boton 1");
        boton1.setPreferredSize(new Dimension(400, 70));
        boton1.setBounds(20,210,190,60);
        boton1.setBackground(Color.orange);


        boton2.setText("Boton 2");
        boton2.setPreferredSize(new Dimension(200, 70));
        boton2.setBounds(480,210,190,60);
        boton2.setBackground(Color.green);


        boton3.setText("Restaurar");
        boton3.setPreferredSize(new Dimension(200, 70));
        boton3.setBounds(250,210,190,60);
        boton3.setBackground(Color.magenta);

    }
}