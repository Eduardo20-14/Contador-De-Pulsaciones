
package Contador;

/**
 *
 * @author Eduardo Martinez Becerra
 */
public class Contador {
    int pulsaciones;
      int pu;
      //constructor
      public Contador(){
          pulsaciones=0;
          pu=0;
      }
    
     //asigna la cantidad de pulsaciones 
      public void setPulsaciones(int p){
          pulsaciones=p;
          
      }
      //asignar la cantidad de pulsaciones al segundo boton
      public void setPu(int q){
          pu=q;
      }
   //devolver las pulsaciones al primer boton  
      public int getPulsaciones(){
          return pulsaciones;
      }
      public int getpu(){
          return pu;
      }
      //incrementar en uno las pulsaciones
      public void incrementa(){
          pulsaciones++;
          
      }
      public void incrementa1(){
          pu++;
          ;
      }
      //contadores a 0
      public void reinicio(){
          pulsaciones =0;
          pu=0;
      }
      public static void main(String[]args){
      }
}

